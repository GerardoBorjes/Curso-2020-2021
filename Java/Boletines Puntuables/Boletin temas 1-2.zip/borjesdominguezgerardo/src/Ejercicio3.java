
package src;

import javax.swing.JOptionPane;

public class Ejercicio3 {

    public static void main(String[] args) {

        // Decidí utilizar un Panel como método de entrada
        String fraseDelUsuario = JOptionPane.showInputDialog("Escribe una frase");

        // Para saber el número de palabras creo un array que las almacene y muestro su
        // longitud
        String[] palabras = fraseDelUsuario.split(" ");
        System.out.println("Palabras en la frase: " + palabras.length);

        // Utilizo replace para reemplazar los espacios por strings vacíos y muestro la
        // longitud que representa el número de caracteres
        System.out.println("Número de caracteres sin espacios: " + (fraseDelUsuario.replaceAll(" ", "")).length());

        // Mostrando true o false si el primer caracter es un dígito o no
        System.out.println("Primer caracter es dígito: " + Character.isDigit(fraseDelUsuario.charAt(0)));

        // Printando el índice del primer espacio
        System.out.println("Índice del primer espacio: " + fraseDelUsuario.indexOf(" "));
    }

}
