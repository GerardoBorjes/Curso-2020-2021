
package src;

import java.util.Arrays;
import java.util.Random;
import javax.swing.JOptionPane;

/**
 * Ejercicio1
 */
public class Ejercicio1 {

    // Crear un programa en Java que utilice una matriz con capacidad para 10
    // enteros , le dé los siguientes valores
    public static void main(String[] args) {
        // Declaración de ambos arrays
        int[] array = new int[10], arrayCopiado = new int[10];

        // Utilizando la calse random para generar un número aleatorio entre 1 y 10
        Random rand = new Random();
        array[0] = rand.nextInt(10) + 1;

        // Sumando 10 al número generado
        array[1] = array[0] + 10;

        // Aplicando las operaciones con los métodos de la calse Math
        array[2] = (int) Math.sqrt((Math.pow(array[0], 3) + Math.pow(array[1], 2)));

        // Haciendo la media de los valores previos del array
        array[3] = (int) (array[0] + array[1] + array[2]) / 3;

        // Solicitando información con JOptionPane
        array[4] = Integer.parseInt(JOptionPane.showInputDialog("Introduzca valor para quinto número en el array"));

        // Llenando el resto del array, (he usado un for para no complicarme demasiado)
        for (int i = 5; i < array.length; i++) {
            array[i] = i;
        }

        // Copiando el array con la clase de utilidad de arrays
        arrayCopiado = Arrays.copyOf(array, 10);

        // Ordenando el array de menor a mayor
        Arrays.sort(arrayCopiado);

        /*
         * Printando la posición del número 1 en ambos arrays (A pesar de que el primer
         * array pueda fallar debido a que está desordenado)
         */
        System.out.println("El número 1 está en la posición " + Arrays.binarySearch(array, 1)
                + " En el primer array, y en la posición " + Arrays.binarySearch(arrayCopiado, 1) + " En el segundo");

        // Printando el booleano que genera Arrays.equals(obj,obj)
        System.out.println(Arrays.equals(array, arrayCopiado));

        /*
         * Mostrando ambos arrays por pantalla sacando partido al método
         * Arrays.toString()
         */
        System.out.println(Arrays.toString(array) + " " + Arrays.toString(arrayCopiado));

    }

}
