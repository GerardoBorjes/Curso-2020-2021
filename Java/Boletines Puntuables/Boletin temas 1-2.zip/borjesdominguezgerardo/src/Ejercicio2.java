
package src;

import java.util.Scanner;

public class Ejercicio2 {

    public static void main(String[] args) {

        // Declarando el Scanner y solicitando el Iban por consola
        Scanner reader = new Scanner(System.in);
        System.out.println("Introduzca su IBAN");
        String iban = reader.nextLine();

        // Utilizando el método Substring para obtener diferentes partes del IBAN
        System.out.println("Código de país: " + iban.substring(0, 2));
        System.out.println("Dígito de control: " + iban.substring(2, 4));
        System.out.println("Código de la caja: " + iban.substring(4, 8));

        // Usando el método equals combinado con substring para comprobar si son iguales
        // ambos Dígitos de control
        System.out.println("Dígitos de control coindicentes: " + (iban.substring(2, 4).equals(iban.substring(12, 14))));

        System.out.println("Número de cuenta: " + iban.substring(14));

        // Mostrando el número de caracteres del IBAN
        System.out.println("Número total de caracteres del IBAN: " + iban.length());

        // Comprobando si el iban comienza por ES
        System.out.println("Comienza por \"ES\": " + iban.startsWith("ES"));

        // Mostrando el dígito de control en binario usando el método toBinaryString
        System.out.println(
                "Dígito de control en binario: " + Integer.toBinaryString(Integer.parseInt(iban.substring(2, 4))));

        reader.close();
    }

}
