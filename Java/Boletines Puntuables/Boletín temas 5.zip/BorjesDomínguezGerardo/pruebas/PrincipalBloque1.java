package pruebas;

import BloqueEjercicios1.MisMetodos;
import java.util.Scanner;

public class PrincipalBloque1 {

    static Scanner scan = new Scanner(System.in);

    public static void main(String[] args) {
        boolean salir = false;

        do {
            System.out.println("1.Llenar Matriz con números aleatorios "
                    + "\n2.Llenar Matriz Con números aleatorios comprendidos entre un rango"
                    + "\n3.Descifrar letra de dni dado el número de dicho dni"
                    + "\n4.Comprobar si la letra de un dni es correcta"
                    + "\n5.Buscar la primera vez que aparece un número en una matriz y devolver su posición"
                    + "\n6.Buscar un número en una matriz y devolver su última posición "
                    + "\n7. Calcular el mínimo común múltiplo de 3 números"
                    + "\n8.Devolver el máximo valor de una colección de números"
                    + "\n9.Método que devuelve una copia de un array ordenado de mayor a menor"
                    + "\n10.Comprobar seguridad en una contraseña" + "\nOtro número: Salir");
            scan = new Scanner(System.in);
            int index = scan.nextInt();
            switch (index) {
                case 1:
                    int[] array = new int[20];
                    MisMetodos.FillWithRandom(array);
                    System.out.println(MisMetodos.ArrayValuesToString(array));
                    break;
                case 2:
                    int[] array2 = new int[20];
                    MisMetodos.FillWithRandom(array2, 10, 51);
                    System.out.println(MisMetodos.ArrayValuesToString(array2));

                    break;
                case 3:
                    System.out.println(MisMetodos.GetDniChar("54505505"));
                    break;
                case 4:
                    if (MisMetodos.VerifyDniLetter("54505505J")) {
                        System.out.println("Dni correctísimo");
                    } else {
                        System.out.println("Letra del dni incorrecta");
                    }
                    break;
                case 5:
                    int[] array3 = { 0, 1, 2, 3, 4, 5, 6, 7, 3 };
                    System.out.println(MisMetodos.ArraySearch(array3, 3));
                    break;
                case 6:
                    int[] array4 = { 0, 1, 2, 3, 4, 5, 6, 7, 3 };
                    System.out.println(MisMetodos.ArraySearch(array4, 3, true));
                    break;
                case 7:
                    System.out.println(MisMetodos.LCM(12, 34, 22));
                    break;
                case 8:
                    int[] array5 = { 0, 1, 2, 3, 4, 5, 6, 7, 3 };
                    System.out.println(MisMetodos.GetMaxOfArray(array5));
                    break;
                case 9:

                    int[] array6 = { 2, 5, 12, 7, 3, 73, 2, 5, 545, 322 };
                    int[] array6Ordenado = MisMetodos.BubbleSort(array6);
                    System.out.println(MisMetodos.ArrayValuesToString(array6Ordenado));

                    break;
                case 10:

                    System.out.println(MisMetodos.PasswordSecurity("NacíEn2001?"));
                    break;

                default:
                    salir = true;
                    break;
            }

        } while (!salir);
        scan.close();
    }

}
