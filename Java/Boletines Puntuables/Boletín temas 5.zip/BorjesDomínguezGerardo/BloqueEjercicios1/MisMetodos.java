package BloqueEjercicios1;

import java.util.Arrays;
import java.util.Random;

/**
 * MisMetodos
 */

// NOTA: Los métodos están ordenados al revés, es decir, los primeros ejercicios
// del boletín corresponden a los últimos métodos del Script.
// Recomiendo leerlos empezando por el final.

public class MisMetodos {
    /**
     * Método que comprueba la segurar de una contraseña introducida como parámetro
     * de tipo String
     * 
     * @param password
     * @return
     */
    public static String PasswordSecurity(String password) {
        // Definimos las siguientes variables de control y las inicializamos todas a
        // false
        boolean mayus, nums, special, minus;
        mayus = nums = special = minus = false;
        // Si la longitud de la contraseña es menor a 6, entonces la contraseña no es
        // válida.
        if (password.length() < 6) {
            return "No válido";
        }
        // Recorremos la cadena
        for (int i = 0; i < password.length(); i++) {
            // Si el caracter en la posición I es un dígito:
            if (!nums && Character.isDigit(password.charAt(i))) {
                // Marcamos que la contraseña tiene dígitos, y pasamos al siguiente caracter
                nums = true;
                continue;
            }
            // Si el caracter en la posición I es minúscula, ésto lo podemos comprobar si el
            // caracter es igual al mismo caracter en minúscula
            if (!minus && password.charAt(i) == password.toLowerCase().charAt(i)) {
                // Marcamos minúsculas y pasamos a la siguiente iteración
                minus = true;
                continue;
            }
            // Si el caracter en la posición I es mayúscula, ésto lo podemos comprobar si el
            // caracter es igual al mismo caracter en minúscula
            if (!mayus && password.charAt(i) == password.toUpperCase().charAt(i)) {
                // Marcamos mayúsculas y pasamos a la siguiente iteración
                mayus = true;
                continue;

            }
            // Para comprobar si el caracter contiene uno de los símbolos dados en el
            // ejercicio, he declarado un string que contiene los símbolos y busco el índice
            // del caracter actual en él, si el índice no es -1 (ya que el método index of
            // devuelve -1 si no encuentra el caracter), quiere decir que el caracter es
            // especial
            if (!special && "/?*$".indexOf(password.charAt(i)) != -1) {
                // Marcamos special y pasamos a la siguiente iteración
                special = true;
                continue;

            }
        }
        // Al final del bucle evaluamos el string a devolver;

        // Si no contenía ni caracteres especiales ni números, devolvemos "Muy débil"
        if (!special && !nums) {
            return "Muy débil";
        }
        // Si no contiene mayúsculas (pero sí caracteres especiales ó números)
        // devolvemos "Débil"
        if (!mayus) {
            return "Débil";
        }
        // Si no contiene caracteres especiales, es decir, contiene solo mayúsculas,
        // minúsculas y números, devolvemos "Media"
        if (!special) {
            return "Media";
        }
        // Si no devolvemos nada hasta ahora, quiere decir que nuestra contraseña cumple
        // con todos los requisitos para devolver "Fuerte"
        return "Fuerte";

    }

    /**
     * Ordena una copia matriz de mayor a menor utilizando el famoso método (y de
     * los menos eficientes entre los algoritmos de ordenación) BubbleSort, y la
     * devuelve.
     * 
     * @param array
     * @return
     */
    public static int[] BubbleSort(int[] array) {
        // Creamos una copia del array utilizando la clase Arrays
        int[] sorted = Arrays.copyOf(array, array.length);
        // Comprobamos si la matriz está ordenada, si no lo está, iteramos sobre ella
        while (!checkDescendantOrder(sorted)) {
            // Recorremos la matriz, pero no hasta el final, la recorremos hasta su
            // penúltima posición para prevenir un error de índice fuera de los límites de
            // la matriz
            for (int i = 0; i < sorted.length - 1; i++) {
                // Si el número en la posición actual es menor que el número en la posición
                // siguiente, los intercambiamos.
                if (sorted[i] < sorted[i + 1]) {
                    int guard = sorted[i];
                    sorted[i] = sorted[i + 1];
                    sorted[i + 1] = guard;
                }
                // Al finalizar una iteración completa, habremos conseguido que el menor número
                // haya "Burbujeado" hasta la última posición de la matriz.
            }
        }
        // Cuando la matriz esté ordenada, la devolvemos.
        return sorted;
    }

    /**
     * Comprueba si una matriz está ordenada de mayor a menor
     * 
     * @param array
     * @return
     */
    static boolean checkDescendantOrder(int array[]) {
        for (int i = 0; i < array.length - 1; i++) {
            if (array[i] < array[i + 1]) {
                return false;
            }
        }
        return true;
    }

    /**
     * Devuelve el valor más alto de los argumentos de tipo entero pasados a la
     * función
     * 
     * @param n
     * @return
     */
    public static int GetMaxOfArray(int... n) {
        // Igualamos el máximo a la primera posición del array
        int max = n[0];
        // Recorremos los argumentos
        for (int i = 1; i < n.length; i++) {
            // Si nuestra variable max es menor que el argumento de I, igualamos max a su
            // valor
            if (max < n[i]) {
                max = n[i];
            }
        }
        // Devolvemos el valor máximo
        return max;
    }

    // En la siguiente región se encuentran todos los métodos que hacen referencia
    // al ejercicio del mínimo común múltiplo
    // #region Mínimo Común Múltiplo
    /**
     * Método que recibe argumentos variables de tipo entero y devuelve el mínimo
     * común múltiplo de todos.
     * 
     * @param n
     * @return
     */
    public static int LCM(int... n) {
        // Inicio la variable result a 1 para que no afecte a las multiplicaciones y
        // divisiones más adelante
        int result = 1;
        for (int i = 0; i < n.length; i++) {
            // Igualo result al mínimo común múltiplo de result y el argumento de I,
            result = LCM(result, n[i]);
        }
        // Al final del bucle, result es igual al mínimo común múltiplo de todos los
        // argumentos.
        return result;
    }

    /**
     * Método que devuelve el mínimo común múltiplo de tres números
     * 
     * @param a
     * @param b
     * @param c
     * @return
     */

    public static int LCM(int a, int b, int c) {
        // Para devolver el mínimo común múltiplo de 3 números podemos encontrar primero
        // el mínimo común múltiplo de 2 números, y tras eso, encontrar
        // El mínimo común múltiplo del resultado de la primera búsqueda y el tercer
        // número
        return LCM((LCM(a, b)), c);
        // Explicación práctica del método:
        // Imaginemos que el introducimos el 12, el 18 y el 30, por ejemplo.
        // El mínimo común múltiplo de 12, 18 y 30 es 180
        // El mínimo común múltiplo de 12 y 18 es 36, y el de 36 (mcm de los dos
        // anteriores) y 30 es 180 también.

    }

    /**
     * Método que devuelve el mínimo común múltiplo de dos números
     * 
     * @param a
     * @param b
     * @return
     */
    public static int LCM(int a, int b) {
        // Para obtener el mínimo común múltiplo de dos números podemos hacer lo
        // siguiente, que es multiplicar ambos números y dividirlos entre su máximo
        // común divisor
        return (a * b) / GreatestSharedDivisor(a, b);

        // Explicación práctica del método:
        // Imaginemos que entran en la función el número 18 y el número 12.
        // 18*12 es 216, si lo dividimos entre su máximo divisor común, obtenemos el
        // número 36, que es precisamente el mínimo común múltiplo de 12 y 18
    }

    /**
     * Método recursivo que devuelve el mayor múltiplo común de dos números
     * 
     * @param num1
     * @param num2
     * @return
     */
    static int GreatestSharedDivisor(int num1, int num2) {
        // Si el segundo número (resto del primer número entre el segundo) es igual a 0,
        // devolvemos el primer número, será el mayor
        // divisor común de ambos
        if (num2 == 0) {
            return num1;
        } else {
            // En caso de no ser 0, iteraremos sobre éste mismo método, pasaremos el segundo
            // número como primer parámetro
            // Y como segundo número pasaremos el resto del primer número entre el segundo;
            return (GreatestSharedDivisor(num2, num1 % num2));
        }
        // Explicación práctica del método:
        // Imaginemos que entran en éste método el número 18 y el número 12;
        // Tras la primera iteración el número que entrará serán el 12 como primer
        // parámetro y el resto de 18 entre 12, que es 6.
        // Como 6 no es 0, entran en la siguiente iteración, el 6 y el resto de 12 entre
        // 6, que sí es 0.
        // Como el segundo parámetro es 0, entonces la función retornará el 6, que es el
        // máximo multiplicador común entre 18 y 12

    }

    // #endregion
    /**
     * Devuelve la primera aparición de un número dado en el array dado
     * 
     * @param array
     * @param num
     * @return
     */
    public static int ArraySearch(int array[], int num) {
        // Recorremos el array con un for
        for (int i = 0; i < array.length; i++) {
            // Sencillamente si el valor en la posición i es igual al número introducido, lo
            // devolvemos
            if (array[i] == num) {
                return i;
            }
        }
        // En caso de no encontrar dicho valor, devolvemos un -1
        return -1;
    }

    /**
     * Busca la primera o la última posición de un integer en la matriz dado un
     * array, el número a buscar y un boolean. si es true, retornará la última
     * posición, si es false, la primera
     * 
     * @param array
     * @param num
     * @param reverse
     * @return
     */
    public static int ArraySearch(int array[], int num, boolean reverse) {
        if (!reverse) {
            // Si reverse es false llamo al método del ejercicio anterior tanto como para
            // claridad
            // en el código como para no copiar dos veces lo mismo
            return ArraySearch(array, num);
        }
        // Si reverse es true, la búsqueda la hago de forma invertida, entonces devuelvo
        // la primera posición donde aparece el número, pero empezando desde el final
        for (int i = array.length - 1; i >= 0; i--) {
            if (array[i] == num) {
                return i;
            }
        }
        // En caso de no encontrar el número, devolvemos -1
        return -1;
    }

    /**
     * Verifica que la letra de un dni es correcta dado un String con formato de DNI
     * 
     * @param dni
     * @return
     */
    public static boolean VerifyDniLetter(String dni) {
        // Declaro un String que será todos los caracteres del String que se le pasó a
        // la función salvo el último.
        String dniNum = dni.substring(0, dni.length() - 1);
        // Recojo el caracter en la última posición en una variable de tipo char
        char letter = dni.charAt(dni.length() - 1);
        // Aquí llamo a la función del ejercicio anterior y le paso el string de ésta,
        // ya que devuelve un caracter, si se corresponden, quiere decir que es correcto

        if (letter == GetDniChar(dniNum)) {
            return true;
        }
        return false;
    }

    /**
     * Método que recibe un String con formato de dni sin letra y devuelve su letra
     * correspondiente
     * 
     * @param dni
     * @return
     */
    public static char GetDniChar(String dni) {

        char dniLetter = ' ';
        // Comprobamos que la longitud del dni sea la correcta
        if (dni.length() == 8) {
            for (int i = 0; i < dni.length(); i++) {
                // Comprobamos que el dni esté sólo formado por caracteres numéricos.
                if (Character.isLetter(dni.charAt(i))) {

                    return dniLetter;
                }

            }
            // Creamos un array de chars con las letras en las posiciones correspondientes.
            // He decicido hacerlo de ésta manera por comodidad,
            // Genero un array de chars a partir de un string que contiene las letras
            // ordenadas
            char dniLetters[] = "TRWAGMYFPDXBNJZSQVHLCKE".toCharArray();
            // Hago este try catch para evitar un error de índice en la matriz
            try {
                return dniLetters[Integer.parseInt(dni) % 23];
            } catch (Exception e) {

            }

        }
        // Si la longitud no es correcta, o existe un error de índice, devolvemos un
        // caracter de espacio
        return dniLetter;

    }

    /**
     * Método que recibe un array y lo sobreescribe con números aleatorios
     * 
     * @param array
     */
    public static void FillWithRandom(int array[]) {
        for (int i = 0; i < array.length; i++) {
            // RandomInt es una función que genera un integer aleatorio, sin mínimo ni
            // máximo
            array[i] = RandomInt();
        }
    }

    /**
     * Método que recibe un array y lo sobreescribe con números aleatorios
     * 
     * @param array
     * @param min
     * @param max
     */
    public static void FillWithRandom(int array[], int min, int max) {
        for (int i = 0; i < array.length; i++) {
            // Llamo a la función random range para más claridad en el código, es una
            // función que devuelve un número aleatorio comprendido en un rango
            array[i] = RandomRange(min, max);
        }
    }

    /**
     * Método que genera un entero (número de 16bits) aleatorio
     * 
     * @return
     */
    static int RandomInt() {
        Random rand = new Random();
        return rand.nextInt();
    }

    /**
     * Método que recibe dos enteros como parámetros y devuelve un número
     * comprendido entre el mínimo [inclusive] y el máximo [exclusive]
     * 
     * @param min
     * @param max
     * @return
     */
    static int RandomRange(int min, int max) {
        Random rand = new Random();
        return rand.nextInt(max - min) + min;
    }

    /**
     * Método que dado un array de Objetos, devuelve un string con sus valores
     * 
     * @param obj
     * @return
     */
    public static String ArrayValuesToString(Object obj[]) {
        String values = "";
        for (Object object : obj) {
            values += object.toString() + ", ";
        }
        return values;
    }

    /**
     * Método que dado un array de enteros, devuelve su contenido como una cadena
     * 
     * @param num
     * @return
     */
    public static String ArrayValuesToString(int num[]) {
        String values = "";
        for (Object nums : num) {
            values += nums + ", ";
        }
        return values;
    }
}